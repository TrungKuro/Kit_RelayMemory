---
name: GUIslice Builder issue
about: Issues relating to the GUIslice Builder
title: ''
labels: ''
assignees: ''

---

NOTE: For issues with the GUIslice Builder, please file a report instead at:
https://github.com/ImpulseAdventure/GUIslice-Builder-source/issues
